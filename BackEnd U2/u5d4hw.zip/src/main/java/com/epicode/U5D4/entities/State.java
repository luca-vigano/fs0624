package com.epicode.U5D4.entities;

public enum State {
	IN_CORSO, PRONTO, SERVITO
}
